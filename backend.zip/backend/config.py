class Config:
    DB_HOST = "localhost"
    DB_USER = "postgres"
    DB_PASSWORD = "test123"  
    DB_NAME = "viacargo"
    DB_PORT = 5432
